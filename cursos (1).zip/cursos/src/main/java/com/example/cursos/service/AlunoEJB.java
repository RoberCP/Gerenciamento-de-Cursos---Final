package com.example.cursos.service;

import com.example.cursos.dominio.Aluno;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

@Stateless
@Transactional
public class AlunoEJB {

    @PersistenceContext
    private EntityManager entityManager;

    public void saveOrUpdate(Aluno aluno) {
        if (aluno.getId() == null) {
            entityManager.persist(aluno);
        } else {
            entityManager.merge(aluno);
        }
    }

    public void delete(Long id) {
        Aluno aluno = entityManager.find(Aluno.class, id);
        if (aluno != null) {
            entityManager.remove(aluno);
        }
    }

    public List<Aluno> findAll() {
        return entityManager.createQuery("SELECT a FROM Aluno a", Aluno.class).getResultList();
    }

    public Aluno findById(Long id) {
        return entityManager.find(Aluno.class, id);
    }
}