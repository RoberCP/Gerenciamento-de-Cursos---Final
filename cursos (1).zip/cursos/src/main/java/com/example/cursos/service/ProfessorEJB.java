package com.example.cursos.service;

import com.example.cursos.dominio.Professor;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

@Stateless
@Transactional
public class ProfessorEJB {

    @PersistenceContext
    private EntityManager entityManager;

    public void saveOrUpdate(Professor professor) {
        if (professor.getId() == null) {
            entityManager.persist(professor);
        } else {
            entityManager.merge(professor);
        }
    }

    public void delete(Long id) {
        Professor professor = entityManager.find(Professor.class, id);
        if (professor != null) {
            entityManager.remove(professor);
        }
    }

    public List<Professor> findAll() {
        return entityManager.createQuery("SELECT p FROM Professor p", Professor.class).getResultList();
    }

    public Professor findById(Long id) {
        return entityManager.find(Professor.class, id);
    }
}