package com.example.cursos.service;

import com.example.cursos.dominio.Curso;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

@Stateless
@Transactional
public class CursoEJB {

    @PersistenceContext
    private EntityManager entityManager;

    public void saveOrUpdate(Curso curso) {
        if (curso.getId() == null) {
            entityManager.persist(curso);
        } else {
            entityManager.merge(curso);
        }
    }

    public void delete(Long id) {
        Curso curso = entityManager.find(Curso.class, id);
        if (curso != null) {
            System.out.println("Entrou aqui");
            try {

                entityManager.remove(curso);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public List<Curso> findAll() {
        return entityManager.createQuery("SELECT c FROM Curso c", Curso.class).getResultList();
    }



    public Curso findById(Long id) {
        return entityManager.find(Curso.class, id);
    }
}