package com.example.cursos.view;

import com.example.cursos.dominio.Professor;
import com.example.cursos.service.ProfessorEJB;
import com.example.cursos.suporte.JSFUtil;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.inject.Inject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
public class ProfessorCrudView implements Serializable {

    private Boolean editando;
    private List<Professor> lista;
    private List<Professor> selecionados = new ArrayList<>();
    private Professor selecionado;

    @Inject
    private ProfessorEJB dao;

    @PostConstruct
    public void init() {
        editando = false;
        carregarLista();
        criarProfessor();
    }

    private void criarProfessor() {
        selecionado = new Professor();
    }

    public void carregarLista() {
        lista = dao.findAll();
    }

    public void incluir() {
        editando = true;
        selecionado = new Professor();
    }

    public void alterar() {
        editando = true;
    }

    public void salvar() {
        try {
            editando = false;
            dao.saveOrUpdate(selecionado);
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao salvar os dados.");
        }
    }

    public void excluir() {
        try {
            editando = false;
            dao.delete(selecionado.getId());
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public void excluirSelecionados() {
        try {
            editando = false;
            for (Professor fornecedor : selecionados) {
                dao.delete(fornecedor.getId());
            }
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public void cancelar() {
        editando = false;
        selecionado = null;
    }

    public Boolean getEditando() {
        return editando;
    }

    public void setEditando(Boolean editando) {
        this.editando = editando;
    }

    public List<Professor> getLista() {
        return lista;
    }

    public void setLista(List<Professor> lista) {
        this.lista = lista;
    }

    public Professor getSelecionado() {
        return selecionado;
    }

    public void setSelecionado(Professor selecionado) {
        this.selecionado = selecionado;
    }

    public List<Professor> getSelecionados() {
        return selecionados;
    }

    public void setSelecionados(List<Professor> selecionados) {
        this.selecionados = selecionados;
    }
}