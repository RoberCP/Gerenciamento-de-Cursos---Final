package com.example.cursos.view;

import com.example.cursos.dominio.Aluno;
import com.example.cursos.service.AlunoEJB;
import com.example.cursos.suporte.JSFUtil;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.inject.Inject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
public class AlunoCrudView implements Serializable {

    private Boolean editando;
    private List<Aluno> lista;
    private List<Aluno> selecionados = new ArrayList<>();
    private Aluno selecionado;

    @Inject
    private AlunoEJB dao;

    public void init() {
        editando = false;
        carregarLista();
        criarAluno();
    }

    private void criarAluno() {
        selecionado = new Aluno();
    }

    public void carregarLista() {
        lista = dao.findAll();
    }

    public void incluir() {
        editando = true;
        selecionado = new Aluno();
    }

    public void alterar() {
        editando = true;
    }

    public void salvar() {
        try {
            editando = false;
            dao.saveOrUpdate(selecionado);
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao salvar os dados.");
        }
    }

    public void excluir() {
        try {
            editando = false;
            dao.delete(selecionado.getId());
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public void excluirSelecionados() {
        try {
            editando = false;
            for (Aluno fornecedor : selecionados) {
                dao.delete(fornecedor.getId());
            }
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public void cancelar() {
        editando = false;
        selecionado = null;
    }

    public Boolean getEditando() {
        return editando;
    }

    public void setEditando(Boolean editando) {
        this.editando = editando;
    }

    public List<Aluno> getLista() {
        return lista;
    }

    public void setLista(List<Aluno> lista) {
        this.lista = lista;
    }

    public Aluno getSelecionado() {
        return selecionado;
    }

    public void setSelecionado(Aluno selecionado) {
        this.selecionado = selecionado;
    }

    public List<Aluno> getSelecionados() {
        return selecionados;
    }

    public void setSelecionados(List<Aluno> selecionados) {
        this.selecionados = selecionados;
    }
}