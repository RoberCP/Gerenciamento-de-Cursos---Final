package com.example.cursos.view;

import com.example.cursos.dominio.Aluno;
import com.example.cursos.dominio.Curso;
import com.example.cursos.dominio.CursoAluno;
import com.example.cursos.dominio.Professor;
import com.example.cursos.service.AlunoEJB;
import com.example.cursos.service.CursoEJB;
import com.example.cursos.service.ProfessorEJB;
import com.example.cursos.suporte.JSFUtil;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.inject.Inject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
public class CursoCrudView implements Serializable {

    private Boolean editando;
    private List<Curso> lista;
    private Curso selecionado;
    private List<Curso> selecionados = new ArrayList<>();

    @Inject
    private CursoEJB cursoDao;

    @Inject
    private ProfessorEJB professorDao;

    private List<Professor> professores;

    private CursoAluno alunos;
    private Integer rowIndex;

    private Long professorId;

    public Long getProfessorId() { return professorId; }

    public void setProfessorId(Long professorId) {
        System.out.println("Professor ID: " + professorId);
        this.professorId = professorId;

        if (professorId != null) {
            Professor professor = professorDao.findById(professorId);
            if (professor != null) {
            selecionado.setProfessor(professor);
        }
    }
    }

    public void init() {
        editando = false;
        carregarLista();
        professores = professorDao.findAll();
        selecionado = new Curso();
        selecionado.setProfessor(new Professor());
    }

    public void carregarLista() {
        lista = cursoDao.findAll();
    }

    public void incluir() {
        editando = true;
        selecionado = new Curso();
        selecionado.setProfessor(new Professor());
    }

    public void alterar() {
        editando = true;
    }

    public void salvar() {
        try {
            editando = false;

            cursoDao.saveOrUpdate(selecionado);
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao salvar os dados.");
        }
    }

    public void excluir() {
        try {
            System.out.println("Excluindo curso: " + selecionado.getId());
            editando = false;
            cursoDao.delete(selecionado.getId());
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public void cancelar() {
        editando = false;
        selecionado = null;
    }

    public void incluirItem() {
        rowIndex = null;
        alunos = new CursoAluno();
    }

    public void cancelarItem() {
        rowIndex = null;
        alunos = null;
    }

    public Boolean getEditando() {
        return editando;
    }

    public void setEditando(Boolean editando) {
        this.editando = editando;
    }

    public List<Curso> getLista() {
        return lista;
    }

    public void setLista(List<Curso> lista) {
        this.lista = lista;
    }

    public Curso getSelecionado() {
        return selecionado;
    }

    public void setSelecionado(Curso selecionado) {
        this.selecionado = selecionado;
    }

    public List<Professor> getProfessores() {
        return professores;
    }

    public void setProfessores(List<Professor> professores) {
        this.professores = professores;
    }

    public CursoAluno getAluno() {
        return alunos;
    }

    public void setAluno(CursoAluno alunos) {
        this.alunos = alunos;
    }

    public void excluirSelecionados() {
        try {
            editando = false;
            for (Curso curso : selecionados) {
                cursoDao.delete(curso.getId());
            }
            carregarLista();
        } catch (Exception e) {
            e.printStackTrace();
            JSFUtil.messagemDeErro("Ocorreu um erro ao excluir os dados.");
        }
    }

    public List<Curso> getSelecionados() {
        return selecionados;
    }

    public void setSelecionados(List<Curso> selecionados) {
        this.selecionados = selecionados;
    }

    // Getters and setters
}
