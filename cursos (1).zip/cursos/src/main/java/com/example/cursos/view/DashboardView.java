package com.example.cursos.view;

import com.example.cursos.dominio.Curso;
import com.example.cursos.dominio.Aluno;
import com.example.cursos.service.CursoEJB;
import com.example.cursos.service.AlunoEJB;
import jakarta.annotation.ManagedBean;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;


import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class DashboardView implements Serializable {

    @Inject
    private CursoEJB cursoEJB;

    @Inject
    private AlunoEJB alunoEJB;

    private List<Curso> cursos;
    private List<Aluno> alunos;

    // Carregar cursos e alunos no início
    @PostConstruct
    public void init() {
        cursos = cursoEJB.findAll();
        alunos = alunoEJB.findAll();
    }

    // Getters e Setters

    public CursoEJB getCursoEJB() {
        return cursoEJB;
    }

    public void setCursoEJB(CursoEJB cursoEJB) {
        this.cursoEJB = cursoEJB;
    }

    public AlunoEJB getAlunoEJB() {
        return alunoEJB;
    }

    public void setAlunoEJB(AlunoEJB alunoEJB) {
        this.alunoEJB = alunoEJB;
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    public void setCursos(List<Curso> cursos) {
        this.cursos = cursos;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }
}
