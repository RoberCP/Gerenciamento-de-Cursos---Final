package com.example.cursos.converter;

import com.example.cursos.dominio.Professor;
import com.example.cursos.service.ProfessorEJB;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

@FacesConverter(value = "ProfessorConverter", managed = true)
@ApplicationScoped
public class ProfessorConverter implements Converter<Professor> {

    @Inject
    private ProfessorEJB professorEJB;

    @Override
    public Professor getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return professorEJB.findById(Long.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Professor professor) {
        if (professor == null || professor.getId() == null) {
            return "";
        }
        return String.valueOf(professor.getId());
    }
}
