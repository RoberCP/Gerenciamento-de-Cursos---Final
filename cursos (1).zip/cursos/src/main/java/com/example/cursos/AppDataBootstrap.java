package com.example.cursos;

import com.example.cursos.dominio.Aluno;
import com.example.cursos.dominio.Professor;
import com.example.cursos.service.AlunoEJB;
import com.example.cursos.service.ProfessorEJB;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;

import java.util.logging.Level;
import java.util.logging.Logger;

@Startup
@Singleton
public class AppDataBootstrap {
    @Inject
    AlunoEJB alunoEJB;

    @Inject
    ProfessorEJB professorEJB;

    @PostConstruct
    public void init() {
        System.out.println("Inicializando dados da aplicação...");


        Aluno aluno1 = new Aluno();
        aluno1.setNome("Aluno A");
        aluno1.setCpf("00978978912");
        aluno1.setTelefone("54998009145");
        aluno1.setMatricula("123456");
        alunoEJB.saveOrUpdate(aluno1);

        Aluno aluno2 = new Aluno();
        aluno2.setNome("Aluno B");
        aluno2.setCpf("01978900011");
        aluno2.setTelefone("54988009140");
        aluno2.setMatricula("123456");
        alunoEJB.saveOrUpdate(aluno1);

        Professor professor1 = new Professor();
        professor1.setNome("Professor Xavier");
        professor1.setCpf("01078900010");
        professor1.setTelefone("54900009189");
        professor1.setEspecialidade("Telepatia");
        professorEJB.saveOrUpdate(professor1);

        Professor professor2 = new Professor();
        professor2.setNome("Professor Girafales");
        professor2.setCpf("02022300011");
        professor2.setTelefone("55880005688");
        professor2.setEspecialidade("Humildes presentes");
        professorEJB.saveOrUpdate(professor2);
    }
}
