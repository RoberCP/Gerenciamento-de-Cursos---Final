package com.example.cursos.view;

import com.example.cursos.dominio.Professor;
import com.example.cursos.service.ProfessorEJB;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import jakarta.inject.Inject;

@FacesConverter(value = "professorConverter", managed = true)
public class ProfessorConverter implements Converter<Professor> {

    @Inject
    private ProfessorEJB professorDao;

    @Override
    public Professor getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return professorDao.findById(Long.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Professor value) {
        if (value == null) {
            return "";
        }
        return String.valueOf(value.getId());
    }
}
